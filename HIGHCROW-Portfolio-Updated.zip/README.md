# HIGHCROW website

Static multi-page website for HIGHCROW. No framework or build step is required.

## Deploy
- Upload the contents of this folder to Netlify, or connect this repository to Netlify.
- Replace `[DOMAIN]` in canonical, Open Graph, JSON-LD, sitemap and robots files with the production hostname.
- Confirm the contact details in `assets/main.js`.
- Enable Netlify Forms and submit a test enquiry after deployment.

## Portfolio
The Work page includes the five website URLs supplied by the owner and the VLAKK Officers image/video assets supplied for this portfolio:
- https://prishaenterprises.vercel.app
- https://frostprefab.in
- https://shop.frostprefab.in
- https://trivastram.vercel.app
- https://raat-ki-sawaari.vercel.app

Media files:
- `assets/vlakk-officers-social-ad.png`
- `assets/vlakk-officers-video-01.mp4`
- `assets/vlakk-officers-video-02.mp4`

The website links are presented as project destinations; the site does not claim performance results or testimonials.

## GitHub
Create a repository named `highcrow-website` under your GitHub account, then upload all files and folders from this project to its root. Keep `index.html`, `assets/`, `work/`, and the other page folders at the repository root (do not add an extra enclosing project folder).
