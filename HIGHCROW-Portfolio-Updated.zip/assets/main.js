/* HIGHCROW shared interactions. No libraries or build step required. */
(function(){
  'use strict';
  /* Replace these empty values before launch. WhatsApp is country code + number, digits only. */
  var CONFIG = { whatsapp: '918882213284', email: 'adityatiwari6731@gmail.com' };
  var year = document.querySelectorAll('[data-current-year]');
  year.forEach(function(node){ node.textContent = String(new Date().getFullYear()); });

  var toggle = document.querySelector('.menu-toggle');
  var panel = document.getElementById('nav-panel');
  if (toggle && panel) {
    toggle.addEventListener('click', function(){
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      panel.classList.toggle('is-open', !open);
      toggle.setAttribute('aria-label', open ? 'Open navigation menu' : 'Close navigation menu');
    });
    panel.querySelectorAll('a').forEach(function(link){
      link.addEventListener('click', function(){
        panel.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Open navigation menu');
      });
    });
    document.addEventListener('keydown', function(event){
      if(event.key === 'Escape'){
        panel.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Open navigation menu');
      }
    });
  }

  /* Highlight the active primary navigation item from clean folder URLs. */
  var current = window.location.pathname.replace(/index\.html$/, '').replace(/\/$/, '') || '';
  /* Resolve the current page when opened from an extracted folder on Android (file://). */
  if (window.location.protocol === 'file:') {
    var localParts = current.split('/').filter(Boolean);
    var knownRoutes = ['services','ai-video-ads','website-design','social-media-management','work','about','process','contact','thank-you','privacy-policy'];
    var localTail = localParts.length ? localParts[localParts.length - 1] : '';
    current = knownRoutes.indexOf(localTail) !== -1 ? '/' + localTail : '';
  }
  document.querySelectorAll('[data-nav-path]').forEach(function(link){
    var target = link.getAttribute('data-nav-path').replace(/\/$/, '') || '';
    var isServiceDetail = target === '/services' && ['/ai-video-ads','/website-design','/social-media-management'].indexOf(current) !== -1;
    if (target === current || isServiceDetail) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });

  /* Floating WhatsApp control remains absent until a real number is configured. */
  var waLinks = document.querySelectorAll('[data-whatsapp-link]');
  var digits = String(CONFIG.whatsapp || '').replace(/\D/g, '');
  if (digits) {
    waLinks.forEach(function(link){
      link.href = 'https://wa.me/' + digits;
      link.hidden = false;
      link.setAttribute('rel', 'noopener noreferrer');
    });
  }
  var emailLinks = document.querySelectorAll('[data-email-link]');
  var email = String(CONFIG.email || '').trim();
  if (email) {
    emailLinks.forEach(function(link){
      link.href = 'mailto:' + email;
      link.textContent = email;
    });
  }

  /* Accessible portfolio filtering; cards remain available if JavaScript is disabled. */
  var filterButtons = document.querySelectorAll('[data-work-filter]');
  var pieces = document.querySelectorAll('[data-work-category]');
  if (filterButtons.length && pieces.length) {
    filterButtons.forEach(function(button){
      button.addEventListener('click', function(){
        var filter = button.getAttribute('data-work-filter');
        filterButtons.forEach(function(other){ other.setAttribute('aria-pressed', String(other === button)); });
        pieces.forEach(function(piece){
          var categories = (piece.getAttribute('data-work-category') || '').split(/\s+/);
          piece.hidden = filter !== 'all' && categories.indexOf(filter) === -1;
        });
      });
    });
  }
})();
